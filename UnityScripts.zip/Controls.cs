﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Controls : MonoBehaviour {

	public int speed = 10;
	public int jumpPower = 25;
	float moveX;
	public Text FlatTopText;
	private bool fRight = false;
	public int maxHealth = 100;
	public int healthPoints;
	public Text Health;
	bool hurt = true;




	void Start () {
		FlatTopText.text = "";
		Health.text = "";
	}

	void getHealth() {
		Health.text = "Health: " + healthPoints;
	}
	// Update is called once per frame
	void Update () {
		if (healthPoints > 0) {
			move ();
		}
		if (hurt == true) {
			getHealth ();
			hurt = false;
		}
		if (healthPoints <= 0) {
			SceneManager.LoadScene ("End");
		}
	}

	void move() {
		moveX = Input.GetAxis ("Horizontal");
		if (Input.GetButtonDown ("Jump") && gameObject.GetComponent<Rigidbody2D> ().velocity.y == 0) {
			jump ();
		}
		if (moveX < 0.0f && fRight == false) {
			Flip ();
		}
		else if (moveX > 0.0f && fRight == true ) {
			Flip ();
		}

		gameObject.GetComponent<Rigidbody2D> ().velocity = new Vector2 (moveX * speed, gameObject.GetComponent<Rigidbody2D> ().velocity.y);
	}

	void jump() {
		GetComponent<Rigidbody2D> ().AddForce (Vector2.up * jumpPower);
	}
		
	void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.CompareTag("Jaylen")){
			other.gameObject.SetActive (false);
			//FlatTopText.text = "You got the FlatTop!";
			Destroy (other.gameObject);
			healthPoints -= 10;
			hurt = true;
		}
	}

	void Flip() {
		fRight = !fRight;
		Vector2 localScale = gameObject.transform.localScale;
		localScale.x *= -1; 
		transform.localScale = localScale;
	}
}

