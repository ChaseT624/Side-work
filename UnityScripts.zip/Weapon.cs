﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Weapon : MonoBehaviour {

	public float FireRate = 0;
	public float Damage = 10;
	public LayerMask whatToHit;
	float timeToFire = 0;
	Transform firePoint;
	public Text score;
	public static int scoreCount;
	//public Transform ballTrailPrefab;

	// Use this for initialization
	void Start () {
		scoreCount = 0;
		score.text = "Score: 0";
		}
	public int getScore() {
		return scoreCount;
	}


	void Awake () {
		firePoint = transform.Find("FirePoint");
		if (firePoint == null) {
			Debug.LogError ("No Fire Point");
		}
	}
	
	// Update is called once per frame
	void Update () {
		if (FireRate == 0) {
			if (Input.GetButtonDown ("Fire1")){
				shoot ();
			}
		} else {
			if (Input.GetButton("Fire1") && Time.time > timeToFire) {
				timeToFire = Time.time + 1 / FireRate;
				shoot ();
			}
		}
	}

	void shoot() {
		Vector2 mousePos = new Vector2 (Camera.main.ScreenToWorldPoint (Input.mousePosition).x, Camera.main.ScreenToWorldPoint (Input.mousePosition).y);
		Vector2 firePointPos = new Vector2 (firePoint.position.x, firePoint.position.y);
		RaycastHit2D hit = Physics2D.Raycast (firePointPos, mousePos - firePointPos, 5, whatToHit);
		Effect ();
		Debug.DrawLine (firePointPos, (mousePos - firePointPos) * 100, Color.red);
		if (hit.collider != null) {
				Debug.DrawLine (firePointPos, hit.point, Color.green);
				hit.collider.gameObject.SetActive (false);
				Destroy (hit.collider.gameObject);
				scoreCount += 10;
				score.text = "Score: " + scoreCount;
		}
	}

	void Effect() {
		//Instantiate (ballTrailPrefab, firePoint.position, firePoint.rotation);
	}
}
