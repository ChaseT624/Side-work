﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMover : MonoBehaviour {

	public Transform target;
	public float speed = 1;
	

	void Start()
	{
		GameObject go = GameObject.FindGameObjectWithTag ("Player");
		target = go.transform;
	}


	// Update is called once per frame
	void Update () {
		transform.position = Vector2.MoveTowards (transform.position, target.position, speed * Time.deltaTime);
	}
}
