﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ManageOver : MonoBehaviour {

	public Text over;
	public Button reset;

	void Start () {
		reset.GetComponentInChildren<Text> ().text = "Reset";
		over.text = "Score: " + Weapon.scoreCount;
	}

	public void re() {
		SceneManager.LoadScene ("MainGame");
	}
}
